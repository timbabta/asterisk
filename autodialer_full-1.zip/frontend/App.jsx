import { useState, useEffect, useRef, useCallback } from "react";

// ─── API ──────────────────────────────────────────────────────────────────────
const API = '/autodialer/api/index.php';

async function api(route, method = 'GET', body = null) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' },
  };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(`${API}?route=${route}`, opts);
  if (!res.ok) throw new Error(`API error ${res.status}`);
  return res.json();
}

// ─── Helpers ─────────────────────────────────────────────────────────────────
const fmt = {
  num: n => n == null ? '—' : Number(n).toLocaleString('ru'),
  pct: (a, b) => b ? Math.round(a / b * 100) + '%' : '0%',
  dur: s => s ? `${Math.floor(s/60)}м ${s%60}с` : '—',
  time: dt => dt ? new Date(dt).toLocaleTimeString('ru', { hour:'2-digit', minute:'2-digit' }) : '—',
};

const STATUS_MAP = {
  active:      { bg:'#052E16', border:'#166534', text:'#4ADE80', label:'Активна' },
  paused:      { bg:'#2D1B00', border:'#92400E', text:'#FCD34D', label:'Пауза' },
  done:        { bg:'#1E1B4B', border:'#4338CA', text:'#A5B4FC', label:'Завершена' },
  draft:       { bg:'#1C1917', border:'#44403C', text:'#A8A29E', label:'Черновик' },
  answered:    { bg:'#052E16', border:'#166534', text:'#4ADE80', label:'Ответил' },
  no_answer:   { bg:'#2D0F0F', border:'#7F1D1D', text:'#FCA5A5', label:'Нет ответа' },
  busy:        { bg:'#2D1B00', border:'#92400E', text:'#FCD34D', label:'Занято' },
  failed:      { bg:'#2D0F0F', border:'#7F1D1D', text:'#FCA5A5', label:'Ошибка' },
  max_retries: { bg:'#1C1917', border:'#44403C', text:'#A8A29E', label:'Лимит' },
  congestion:  { bg:'#2D0F0F', border:'#7F1D1D', text:'#FCA5A5', label:'Перегрузка' },
  calling:     { bg:'#042F2E', border:'#134E4A', text:'#5EEAD4', label:'Звоним...' },
  pending:     { bg:'#1C1917', border:'#44403C', text:'#A8A29E', label:'Ожидает' },
};

function Badge({ status }) {
  const s = STATUS_MAP[status] || STATUS_MAP.draft;
  return (
    <span style={{
      background: s.bg, border: `1px solid ${s.border}`, color: s.text,
      padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 700, letterSpacing: 0.5,
      whiteSpace: 'nowrap'
    }}>{s.label}</span>
  );
}

function Card({ children, style }) {
  return (
    <div style={{
      background: '#0C1929', borderRadius: 16, border: '1px solid #1A2D45',
      padding: 24, ...style
    }}>{children}</div>
  );
}

function SectionTitle({ children }) {
  return (
    <div style={{ color: '#4B6380', fontSize: 10, fontWeight: 800, letterSpacing: 2, marginBottom: 16, textTransform:'uppercase' }}>
      {children}
    </div>
  );
}

// ─── IVR Node Editor ──────────────────────────────────────────────────────────
const NODE_DEFS = {
  play:      { icon: '▶', color: '#4ADE80', label: 'Воспроизвести' },
  menu:      { icon: '☰', color: '#60A5FA', label: 'DTMF Меню' },
  transfer:  { icon: '↗', color: '#FCD34D', label: 'Перевод' },
  hangup:    { icon: '✕', color: '#F87171', label: 'Завершить' },
};

function IVRBuilder({ campaignId, ivrPlan, audioFiles, onChange }) {
  const [nodes, setNodes] = useState(() => ivrPlan?.nodes || [
    { id: 1, type: 'play', audio: audioFiles[0]?.filename || 'welcome', label: 'Приветствие', next: 2 },
    { id: 2, type: 'menu', audio: audioFiles[0]?.filename || 'welcome', label: 'Главное меню',
      options: { '1': { label: 'Акция', audio: '', next: null }, '2': { label: 'Оператор', transfer: '100', next: null }, '9': { label: 'Выход', hangup: true } }
    },
  ]);
  const [selected, setSelected] = useState(null);
  const [positions, setPositions] = useState({});
  const [dragging, setDragging] = useState(null);
  const [dragStart, setDragStart] = useState(null);
  const svgRef = useRef();

  // Auto-layout
  useEffect(() => {
    const pos = {};
    nodes.forEach((n, i) => {
      pos[n.id] = pos[n.id] || { x: 60 + (i % 3) * 200, y: 60 + Math.floor(i / 3) * 130 };
    });
    setPositions(p => ({ ...pos, ...p }));
  }, [nodes]);

  useEffect(() => {
    onChange({ nodes });
  }, [nodes]);

  const selNode = nodes.find(n => n.id === selected);
  const nextId = () => Math.max(0, ...nodes.map(n => n.id)) + 1;

  const addNode = type => {
    const id = nextId();
    setNodes(ns => [...ns, { id, type, label: NODE_DEFS[type].label, audio: audioFiles[0]?.filename || '', options: type === 'menu' ? { '1': { label: 'Опция 1', audio: '', next: null } } : undefined }]);
    setPositions(p => ({ ...p, [id]: { x: 80 + Math.random() * 180, y: 80 + Math.random() * 150 } }));
    setSelected(id);
  };

  const deleteNode = id => {
    setNodes(ns => ns.filter(n => n.id !== id));
    setSelected(null);
  };

  const updNode = (id, patch) => setNodes(ns => ns.map(n => n.id === id ? { ...n, ...patch } : n));

  const handleSvgMouseDown = (e, id) => {
    e.stopPropagation();
    setSelected(id);
    const pos = positions[id] || { x: 0, y: 0 };
    setDragging(id);
    setDragStart({ mx: e.clientX, my: e.clientY, ox: pos.x, oy: pos.y });
  };

  const handleMouseMove = e => {
    if (!dragging) return;
    const dx = e.clientX - dragStart.mx;
    const dy = e.clientY - dragStart.my;
    setPositions(p => ({ ...p, [dragging]: { x: Math.max(0, dragStart.ox + dx), y: Math.max(0, dragStart.oy + dy) } }));
  };

  // Build edges from node.next and options
  const edges = [];
  nodes.forEach(n => {
    if (n.next) edges.push({ from: n.id, to: n.next, label: '' });
    if (n.options) {
      Object.entries(n.options).forEach(([key, opt]) => {
        if (opt.next) edges.push({ from: n.id, to: opt.next, label: key });
      });
    }
  });

  const nodeW = 160, nodeH = 56;
  const center = id => {
    const p = positions[id] || { x: 0, y: 0 };
    return { x: p.x + nodeW / 2, y: p.y + nodeH / 2 };
  };

  return (
    <div style={{ display: 'flex', gap: 16, height: 560 }}>
      {/* Canvas */}
      <div style={{ flex: 1, background: '#060E1A', borderRadius: 16, position: 'relative', overflow: 'hidden', border: '1px solid #1A2D45' }}>
        {/* Toolbar */}
        <div style={{ position: 'absolute', top: 10, left: 10, zIndex: 5, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {Object.entries(NODE_DEFS).map(([type, def]) => (
            <button key={type} onClick={() => addNode(type)} style={{
              background: def.color + '15', border: `1px solid ${def.color}40`,
              color: def.color, borderRadius: 8, padding: '4px 10px',
              fontSize: 11, cursor: 'pointer', fontFamily: 'inherit', fontWeight: 700
            }}>+ {def.icon} {def.label}</button>
          ))}
        </div>

        <svg ref={svgRef} width="100%" height="100%"
          onMouseMove={handleMouseMove} onMouseUp={() => setDragging(null)} onMouseLeave={() => setDragging(null)}
          onClick={() => setSelected(null)} style={{ cursor: 'default' }}
        >
          <defs>
            <pattern id="dots" width="20" height="20" patternUnits="userSpaceOnUse">
              <circle cx="1" cy="1" r="0.5" fill="#1A2D45" />
            </pattern>
            <marker id="arr" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
              <path d="M0,0 L0,6 L6,3 z" fill="#2A4060" />
            </marker>
          </defs>
          <rect width="100%" height="100%" fill="url(#dots)" />

          {/* Edges */}
          {edges.map((e, i) => {
            const f = center(e.from), t = center(e.to);
            if (!f || !t) return null;
            const mx = (f.x + t.x) / 2, my = (f.y + t.y) / 2;
            return (
              <g key={i}>
                <path d={`M${f.x},${f.y + nodeH/2} C${f.x},${my + 30} ${t.x},${my - 30} ${t.x},${t.y - nodeH/2}`}
                  fill="none" stroke="#2A4060" strokeWidth={1.5} markerEnd="url(#arr)" />
                {e.label && (
                  <text x={mx} y={my} textAnchor="middle" fill="#4B6380" fontSize={10} fontWeight={800}
                    style={{ pointerEvents: 'none' }}>【{e.label}】</text>
                )}
              </g>
            );
          })}

          {/* Nodes */}
          {nodes.map(node => {
            const pos = positions[node.id] || { x: 80, y: 80 };
            const def = NODE_DEFS[node.type] || NODE_DEFS.hangup;
            const isSel = selected === node.id;
            return (
              <g key={node.id} transform={`translate(${pos.x},${pos.y})`}
                onMouseDown={e => handleSvgMouseDown(e, node.id)} style={{ cursor: 'grab' }}>
                <rect width={nodeW} height={nodeH} rx={10}
                  fill={def.color + '10'} stroke={isSel ? def.color : def.color + '40'} strokeWidth={isSel ? 2 : 1} />
                <text x={12} y={22} fill={def.color} fontSize={14}>{def.icon}</text>
                <text x={32} y={22} fill="#CBD5E1" fontSize={11} fontWeight={700}>{node.label}</text>
                <text x={12} y={40} fill="#4B6380" fontSize={9}>{node.audio || node.number || ''}</text>
              </g>
            );
          })}
        </svg>
      </div>

      {/* Properties panel */}
      <div style={{ width: 260, background: '#0C1929', borderRadius: 16, border: '1px solid #1A2D45', padding: 20, overflowY: 'auto' }}>
        <SectionTitle>Свойства блока</SectionTitle>

        {selNode ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div style={{ color: NODE_DEFS[selNode.type]?.color, fontWeight: 800, fontSize: 13 }}>
              {NODE_DEFS[selNode.type]?.icon} {NODE_DEFS[selNode.type]?.label}
            </div>

            <Field label="Название">
              <Input value={selNode.label} onChange={v => updNode(selNode.id, { label: v })} />
            </Field>

            {(selNode.type === 'play' || selNode.type === 'menu') && (
              <Field label="Аудио файл">
                <Select value={selNode.audio} onChange={v => updNode(selNode.id, { audio: v })}>
                  <option value="">-- выбрать --</option>
                  {audioFiles.map(f => <option key={f.filename} value={f.filename}>{f.label}</option>)}
                </Select>
              </Field>
            )}

            {selNode.type === 'menu' && (
              <div>
                <div style={{ color: '#4B6380', fontSize: 10, fontWeight: 700, letterSpacing: 1, marginBottom: 8 }}>DTMF ОПЦИИ</div>
                {Object.entries(selNode.options || {}).map(([key, opt]) => (
                  <div key={key} style={{ background: '#060E1A', borderRadius: 8, padding: 8, marginBottom: 8, border: '1px solid #1A2D45' }}>
                    <div style={{ color: '#60A5FA', fontWeight: 800, fontSize: 12, marginBottom: 6 }}>Клавиша [{key}]</div>
                    <Input placeholder="Название" value={opt.label} onChange={v => {
                      updNode(selNode.id, { options: { ...selNode.options, [key]: { ...opt, label: v } } });
                    }} />
                    <div style={{ marginTop: 6 }}>
                      <Select value={opt.audio || ''} onChange={v => updNode(selNode.id, { options: { ...selNode.options, [key]: { ...opt, audio: v } } })}>
                        <option value="">Без аудио</option>
                        {audioFiles.map(f => <option key={f.filename} value={f.filename}>{f.label}</option>)}
                      </Select>
                    </div>
                    <div style={{ marginTop: 6, display: 'flex', gap: 4, alignItems: 'center' }}>
                      <input type="checkbox" checked={!!opt.hangup} onChange={e => updNode(selNode.id, { options: { ...selNode.options, [key]: { ...opt, hangup: e.target.checked, transfer: '' } } })} />
                      <label style={{ color: '#94A3B8', fontSize: 11 }}>Завершить звонок</label>
                    </div>
                    {!opt.hangup && (
                      <div style={{ marginTop: 6 }}>
                        <Input placeholder="Перевод (номер/вн.)" value={opt.transfer || ''} onChange={v => updNode(selNode.id, { options: { ...selNode.options, [key]: { ...opt, transfer: v } } })} />
                      </div>
                    )}
                  </div>
                ))}
                <button onClick={() => {
                  const key = prompt('Клавиша (0-9, *, #):');
                  if (key) updNode(selNode.id, { options: { ...selNode.options, [key]: { label: 'Опция ' + key, audio: '', next: null } } });
                }} style={smallBtn}>+ Добавить опцию</button>
              </div>
            )}

            {selNode.type === 'transfer' && (
              <Field label="Номер / Внутренний">
                <Input placeholder="100 или SIP/user" value={selNode.number || ''} onChange={v => updNode(selNode.id, { number: v })} />
              </Field>
            )}

            <Field label="Следующий блок (ID)">
              <Input placeholder="ID узла или пусто" value={selNode.next || ''} onChange={v => updNode(selNode.id, { next: v ? parseInt(v) : null })} />
            </Field>

            <button onClick={() => deleteNode(selNode.id)} style={{ ...smallBtn, color: '#F87171', borderColor: '#7F1D1D', background: '#2D0F0F', marginTop: 4 }}>
              🗑 Удалить блок
            </button>
          </div>
        ) : (
          <div style={{ color: '#2A4060', fontSize: 12, lineHeight: 1.8 }}>
            Выберите блок<br />для редактирования.<br /><br />
            Перетаскивайте<br />блоки мышью.
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Tiny UI primitives ───────────────────────────────────────────────────────
const inputBase = {
  width: '100%', background: '#060E1A', border: '1px solid #1A2D45',
  borderRadius: 8, color: '#CBD5E1', padding: '7px 10px',
  fontSize: 12, fontFamily: 'inherit', boxSizing: 'border-box', outline: 'none'
};
const Input = ({ value, onChange, placeholder, type = 'text', style }) => (
  <input style={{ ...inputBase, ...style }} type={type} value={value ?? ''} placeholder={placeholder}
    onChange={e => onChange(e.target.value)}
    onFocus={e => e.target.style.borderColor = '#3B82F6'}
    onBlur={e => e.target.style.borderColor = '#1A2D45'} />
);
const Select = ({ value, onChange, children, style }) => (
  <select style={{ ...inputBase, ...style }} value={value ?? ''} onChange={e => onChange(e.target.value)}>
    {children}
  </select>
);
const Field = ({ label, children }) => (
  <div>
    <div style={{ color: '#4B6380', fontSize: 10, fontWeight: 700, letterSpacing: 1, marginBottom: 4 }}>{label}</div>
    {children}
  </div>
);
const smallBtn = {
  background: '#0C1929', border: '1px solid #1A2D45', color: '#64748B',
  borderRadius: 8, padding: '5px 12px', cursor: 'pointer', fontSize: 11, fontFamily: 'inherit', width: '100%'
};
const Btn = ({ children, onClick, color = '#3B82F6', style }) => (
  <button onClick={onClick} style={{
    background: color, color: color === '#3B82F6' ? '#fff' : '#fff',
    border: 'none', borderRadius: 10, padding: '9px 20px',
    fontWeight: 700, cursor: 'pointer', fontSize: 13, fontFamily: 'inherit', ...style
  }}>{children}</button>
);

// ─── New Campaign Modal ───────────────────────────────────────────────────────
function NewCampaignModal({ audioFiles, onClose, onSaved }) {
  const [step, setStep] = useState(1); // 1=info, 2=phones, 3=ivr
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [ivrPlan, setIvrPlan] = useState(null);
  const [form, setForm] = useState({
    name: '', audio_file: '', max_retries: 3, retry_delay: 300,
    time_from: '09:00', time_to: '20:00', caller_id: '70000000000', phones: ''
  });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const phoneCount = form.phones.split(/[\n,;]+/).filter(p => p.trim().length > 5).length;

  const save = async () => {
    if (!form.name) return setError('Введите название');
    if (!form.audio_file) return setError('Выберите аудио файл');
    setSaving(true);
    try {
      const body = { ...form, ivr_plan: ivrPlan };
      await api('campaigns', 'POST', body);
      onSaved();
      onClose();
    } catch (e) { setError(e.message); }
    setSaving(false);
  };

  return (
    <div style={{ position: 'fixed', inset: 0, background: '#000000BB', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ background: '#0C1929', borderRadius: 20, border: '1px solid #1A2D45', width: step === 3 ? 900 : 560, maxHeight: '92vh', overflowY: 'auto' }}>
        {/* Header */}
        <div style={{ padding: '24px 28px', borderBottom: '1px solid #1A2D45', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontWeight: 800, fontSize: 18, color: '#F1F5F9' }}>Новая кампания</div>
            <div style={{ color: '#4B6380', fontSize: 12, marginTop: 2 }}>Шаг {step} из 3</div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            {[1,2,3].map(s => (
              <div key={s} onClick={() => step > s && setStep(s)} style={{
                width: 28, height: 28, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: step === s ? '#3B82F6' : step > s ? '#166534' : '#1A2D45',
                color: step >= s ? '#fff' : '#4B6380', fontSize: 12, fontWeight: 700,
                cursor: step > s ? 'pointer' : 'default'
              }}>{step > s ? '✓' : s}</div>
            ))}
          </div>
        </div>

        <div style={{ padding: 28 }}>
          {error && <div style={{ background: '#2D0F0F', border: '1px solid #7F1D1D', color: '#FCA5A5', borderRadius: 10, padding: '10px 14px', marginBottom: 16, fontSize: 13 }}>⚠ {error}</div>}

          {/* Step 1: Основное */}
          {step === 1 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <Field label="Название кампании *">
                <Input value={form.name} onChange={v => set('name', v)} placeholder="Акция июнь 2026" />
              </Field>
              <Field label="Основной аудио файл *">
                <Select value={form.audio_file} onChange={v => set('audio_file', v)}>
                  <option value="">-- выбрать файл --</option>
                  {audioFiles.map(f => <option key={f.filename} value={f.filename}>{f.label} ({f.filename})</option>)}
                </Select>
              </Field>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
                <Field label="Макс. попыток">
                  <Input type="number" value={form.max_retries} onChange={v => set('max_retries', v)} />
                </Field>
                <Field label="Пауза между попытками (сек)">
                  <Input type="number" value={form.retry_delay} onChange={v => set('retry_delay', v)} />
                </Field>
                <Field label="Номер отправителя">
                  <Input value={form.caller_id} onChange={v => set('caller_id', v)} placeholder="70000000000" />
                </Field>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <Field label="Звонить с">
                  <Input type="time" value={form.time_from} onChange={v => set('time_from', v)} />
                </Field>
                <Field label="Звонить до">
                  <Input type="time" value={form.time_to} onChange={v => set('time_to', v)} />
                </Field>
              </div>
            </div>
          )}

          {/* Step 2: Номера */}
          {step === 2 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div style={{ color: '#94A3B8', fontSize: 13 }}>
                Введите номера телефонов — по одному в строке или через запятую.<br />
                Поддерживается формат: 79991234567, +79991234567, 89991234567
              </div>
              <Field label={`Номера телефонов (${phoneCount} шт.)`}>
                <textarea
                  style={{ ...inputBase, height: 220, resize: 'vertical', lineHeight: 1.6 }}
                  placeholder={"+79991234567\n+79167654321\n+79031234567\n..."}
                  value={form.phones}
                  onChange={e => set('phones', e.target.value)}
                />
              </Field>
              {phoneCount > 0 && (
                <div style={{ background: '#052E16', border: '1px solid #166534', borderRadius: 10, padding: '10px 14px', color: '#4ADE80', fontSize: 13 }}>
                  ✓ Найдено {phoneCount} номеров для обзвона
                </div>
              )}
            </div>
          )}

          {/* Step 3: IVR */}
          {step === 3 && (
            <div>
              <div style={{ color: '#94A3B8', fontSize: 13, marginBottom: 16 }}>
                Постройте логику звонка визуально. Добавляйте блоки и настраивайте сценарий.
                Если не нужен IVR — пропустите этот шаг.
              </div>
              <IVRBuilder campaignId={null} ivrPlan={ivrPlan} audioFiles={audioFiles} onChange={setIvrPlan} />
            </div>
          )}

          {/* Navigation */}
          <div style={{ display: 'flex', gap: 12, marginTop: 24 }}>
            <button onClick={onClose} style={{ ...smallBtn, flex: 1, padding: 10 }}>Отмена</button>
            {step > 1 && (
              <Btn onClick={() => setStep(s => s - 1)} color="#1A2D45" style={{ flex: 1 }}>← Назад</Btn>
            )}
            {step < 3 && (
              <Btn onClick={() => { setError(''); setStep(s => s + 1); }} style={{ flex: 2 }}>Далее →</Btn>
            )}
            {step === 3 && (
              <Btn onClick={save} color="#166534" style={{ flex: 2 }}>
                {saving ? '⏳ Создаём...' : '✓ Создать кампанию'}
              </Btn>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Analytics Tab ────────────────────────────────────────────────────────────
function Analytics({ data }) {
  if (!data) return <div style={{ color: '#4B6380', padding: 40, textAlign: 'center' }}>Загрузка...</div>;
  const { totals, by_day, by_campaign, dtmf } = data;
  const maxDay = Math.max(...(by_day || []).map(d => +d.answered + +d.failed), 1);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {/* KPI */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
        {[
          { label: 'Всего звонков', val: fmt.num(totals?.total_calls), sub: 'за 30 дней', c: '#60A5FA' },
          { label: 'Дозвонились', val: fmt.num(totals?.total_answered), sub: fmt.pct(totals?.total_answered, totals?.total_calls), c: '#4ADE80' },
          { label: 'Не дозвонились', val: fmt.num(totals?.total_failed), sub: fmt.pct(totals?.total_failed, totals?.total_calls), c: '#F87171' },
          { label: 'Среднее время', val: fmt.dur(Math.round(totals?.avg_duration)), sub: 'разговора', c: '#FCD34D' },
        ].map(k => (
          <Card key={k.label}>
            <div style={{ color: k.c, fontSize: 32, fontWeight: 900, fontFamily: 'Georgia, serif', letterSpacing: -1 }}>{k.val}</div>
            <div style={{ color: '#94A3B8', fontSize: 12, fontWeight: 600, marginTop: 4 }}>{k.label}</div>
            <div style={{ color: '#4B6380', fontSize: 11, marginTop: 2 }}>{k.sub}</div>
          </Card>
        ))}
      </div>

      {/* Chart */}
      <Card>
        <SectionTitle>Звонки по дням</SectionTitle>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 10, height: 140 }}>
          {(by_day || []).map(d => {
            const aH = Math.round((+d.answered / maxDay) * 120);
            const fH = Math.round((+d.failed / maxDay) * 120);
            const total = +d.answered + +d.failed;
            return (
              <div key={d.day} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
                <div style={{ fontSize: 9, color: '#4B6380', fontWeight: 700 }}>{total}</div>
                <div style={{ width: '60%', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', height: 120 }}>
                  <div style={{ width: '100%', height: fH, background: '#F8717130', border: '1px solid #F87171', borderRadius: '3px 3px 0 0', marginBottom: 1 }} />
                  <div style={{ width: '100%', height: aH, background: '#4ADE8030', border: '1px solid #4ADE80', borderRadius: '3px 3px 0 0' }} />
                </div>
                <div style={{ color: '#4B6380', fontSize: 10 }}>{String(d.day).slice(5)}</div>
              </div>
            );
          })}
          {(!by_day || by_day.length === 0) && (
            <div style={{ color: '#2A4060', flex: 1, textAlign: 'center', paddingTop: 50 }}>Нет данных за 7 дней</div>
          )}
        </div>
        <div style={{ display: 'flex', gap: 20, marginTop: 10 }}>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <div style={{ width: 10, height: 10, background: '#4ADE8030', border: '1px solid #4ADE80', borderRadius: 2 }} />
            <span style={{ color: '#4B6380', fontSize: 11 }}>Дозвонились</span>
          </div>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <div style={{ width: 10, height: 10, background: '#F8717130', border: '1px solid #F87171', borderRadius: 2 }} />
            <span style={{ color: '#4B6380', fontSize: 11 }}>Не дозвонились</span>
          </div>
        </div>
      </Card>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 20 }}>
        {/* By campaign */}
        <Card>
          <SectionTitle>По кампаниям</SectionTitle>
          {(by_campaign || []).map(c => (
            <div key={c.id} style={{ marginBottom: 16 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <span style={{ color: '#CBD5E1', fontWeight: 600, fontSize: 13 }}>{c.name}</span>
                <span style={{ color: '#4ADE80', fontWeight: 800, fontSize: 13 }}>{c.conversion || 0}%</span>
              </div>
              <div style={{ height: 4, background: '#1A2D45', borderRadius: 4 }}>
                <div style={{ width: `${c.conversion || 0}%`, height: '100%', background: 'linear-gradient(90deg,#4ADE80,#60A5FA)', borderRadius: 4 }} />
              </div>
              <div style={{ color: '#4B6380', fontSize: 11, marginTop: 4 }}>
                {fmt.num(c.calls)} звонков · {fmt.num(c.answered)} ответило · {fmt.num(c.failed)} нет
              </div>
            </div>
          ))}
          {!by_campaign?.length && <div style={{ color: '#2A4060', fontSize: 13 }}>Нет данных</div>}
        </Card>

        {/* DTMF */}
        <Card>
          <SectionTitle>Нажатия клавиш (DTMF)</SectionTitle>
          {(dtmf || []).map(d => (
            <div key={d.key_} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
              <div style={{ width: 32, height: 32, borderRadius: 8, background: '#1A2D45', border: '1px solid #2A4060', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#60A5FA', fontWeight: 800, fontSize: 14 }}>
                {d.key_}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ height: 4, background: '#1A2D45', borderRadius: 4 }}>
                  <div style={{ width: `${Math.min(100, d.cnt / (dtmf[0]?.cnt || 1) * 100)}%`, height: '100%', background: '#60A5FA', borderRadius: 4 }} />
                </div>
              </div>
              <div style={{ color: '#60A5FA', fontWeight: 800, fontSize: 13, minWidth: 30 }}>{d.cnt}</div>
            </div>
          ))}
          {!dtmf?.length && <div style={{ color: '#2A4060', fontSize: 13 }}>Нет данных о DTMF</div>}
        </Card>
      </div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState('campaigns');
  const [campaigns, setCampaigns] = useState([]);
  const [calls, setCalls] = useState([]);
  const [audioFiles, setAudioFiles] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);
  const [uploadFile, setUploadFile] = useState(null);
  const [uploadLabel, setUploadLabel] = useState('');
  const [uploading, setUploading] = useState(false);
  const [liveCount, setLiveCount] = useState(0);
  const fileInputRef = useRef();

  const loadAll = useCallback(async () => {
    try {
      const [c, cl, a, an] = await Promise.all([
        api('campaigns'), api('calls'), api('audio'), api('analytics')
      ]);
      setCampaigns(c); setCalls(cl); setAudioFiles(a); setAnalytics(an);
      setLiveCount(c.filter(x => x.status === 'active').length);
    } catch (e) {
      console.error('Load error', e);
    }
    setLoading(false);
  }, []);

  useEffect(() => { loadAll(); }, []);

  // Auto-refresh every 10s when there are active campaigns
  useEffect(() => {
    const t = setInterval(() => { if (liveCount > 0) loadAll(); }, 10000);
    return () => clearInterval(t);
  }, [liveCount, loadAll]);

  const toggleStatus = async (c) => {
    const newStatus = c.status === 'active' ? 'paused' : 'active';
    await api('campaigns', 'PUT', { status: newStatus }, `&id=${c.id}`);
    loadAll();
  };

  // Override api for PUT with id in query
  const apiPut = async (route, body, id) => {
    const res = await fetch(`${API}?route=${route}&id=${id}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
    });
    return res.json();
  };

  const handleToggle = async (c) => {
    const newStatus = c.status === 'active' ? 'paused' : 'active';
    await apiPut('campaigns', { status: newStatus }, c.id);
    loadAll();
  };

  const handleUploadAudio = async () => {
    if (!uploadFile) return;
    setUploading(true);
    const fd = new FormData();
    fd.append('file', uploadFile);
    fd.append('label', uploadLabel || uploadFile.name);
    await fetch(`${API}?route=audio`, { method: 'POST', body: fd });
    setUploading(false);
    setUploadFile(null);
    setUploadLabel('');
    loadAll();
  };

  const TABS = [
    { id: 'campaigns', label: '📋 Кампании' },
    { id: 'calls',     label: '📞 Звонки' },
    { id: 'audio',     label: '🎵 Аудио' },
    { id: 'analytics', label: '📊 Аналитика' },
  ];

  return (
    <div style={{ minHeight: '100vh', background: '#060E1A', fontFamily: "'DM Sans', 'Segoe UI', sans-serif", color: '#CBD5E1' }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,600;0,9..40,700;0,9..40,800;0,9..40,900&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        @keyframes pulse { 0%,100%{opacity:1;} 50%{opacity:.3;} }
        @keyframes spin { to { transform: rotate(360deg); } }
        ::-webkit-scrollbar { width: 5px; }
        ::-webkit-scrollbar-track { background: #060E1A; }
        ::-webkit-scrollbar-thumb { background: #1A2D45; border-radius: 3px; }
      `}</style>

      {/* ── Sidebar ──────────────────────────────────────────────── */}
      <div style={{ position: 'fixed', left: 0, top: 0, bottom: 0, width: 220, background: '#0C1929', borderRight: '1px solid #1A2D45', display: 'flex', flexDirection: 'column', zIndex: 10 }}>
        {/* Logo */}
        <div style={{ padding: '24px 20px', borderBottom: '1px solid #1A2D45' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 38, height: 38, background: 'linear-gradient(135deg,#1D4ED8,#0EA5E9)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>📡</div>
            <div>
              <div style={{ fontWeight: 900, fontSize: 16, letterSpacing: -0.5, color: '#F1F5F9' }}>AutoDial</div>
              <div style={{ fontSize: 9, color: '#4B6380', fontWeight: 700, letterSpacing: 1 }}>ASTERISK · MYSQL</div>
            </div>
          </div>
        </div>

        {/* Live indicator */}
        {liveCount > 0 && (
          <div style={{ margin: '12px 16px 0', background: '#052E16', border: '1px solid #166534', borderRadius: 10, padding: '8px 12px', display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 7, height: 7, background: '#4ADE80', borderRadius: '50%', animation: 'pulse 1.5s infinite' }} />
            <span style={{ color: '#4ADE80', fontSize: 11, fontWeight: 700 }}>{liveCount} активных</span>
          </div>
        )}

        {/* Nav */}
        <nav style={{ padding: '16px 10px', flex: 1 }}>
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              width: '100%', textAlign: 'left', padding: '10px 12px', borderRadius: 10, border: 'none',
              background: tab === t.id ? '#1A2D45' : 'transparent',
              color: tab === t.id ? '#93C5FD' : '#4B6380',
              fontSize: 13, fontWeight: tab === t.id ? 700 : 600, cursor: 'pointer',
              fontFamily: 'inherit', marginBottom: 2,
              borderLeft: tab === t.id ? '3px solid #3B82F6' : '3px solid transparent'
            }}>{t.label}</button>
          ))}
        </nav>

        <div style={{ padding: '16px', borderTop: '1px solid #1A2D45' }}>
          <Btn onClick={() => setShowNew(true)} color="#1D4ED8" style={{ width: '100%', fontSize: 12 }}>
            + Новая кампания
          </Btn>
        </div>
      </div>

      {/* ── Main ─────────────────────────────────────────────────── */}
      <div style={{ marginLeft: 220, padding: 28, minHeight: '100vh' }}>
        {loading && (
          <div style={{ textAlign: 'center', paddingTop: 100, color: '#4B6380' }}>
            <div style={{ fontSize: 32, animation: 'spin 1s linear infinite', display: 'inline-block' }}>⟳</div>
            <div style={{ marginTop: 12 }}>Загрузка...</div>
          </div>
        )}

        {/* ── Campaigns ──────────────────────────────────────────── */}
        {!loading && tab === 'campaigns' && (
          <div>
            <div style={{ marginBottom: 24, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <h1 style={{ fontSize: 22, fontWeight: 900, color: '#F1F5F9' }}>Кампании</h1>
                <div style={{ color: '#4B6380', fontSize: 13, marginTop: 4 }}>{campaigns.length} всего</div>
              </div>
              <Btn onClick={() => setShowNew(true)}>+ Создать</Btn>
            </div>

            {campaigns.length === 0 ? (
              <Card style={{ textAlign: 'center', padding: 60 }}>
                <div style={{ fontSize: 48, marginBottom: 16 }}>📋</div>
                <div style={{ color: '#4B6380', fontSize: 16 }}>Нет кампаний</div>
                <div style={{ color: '#2A4060', fontSize: 13, marginTop: 8 }}>Создайте первую кампанию для начала</div>
                <Btn onClick={() => setShowNew(true)} style={{ marginTop: 20 }}>Создать кампанию</Btn>
              </Card>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                {campaigns.map(c => {
                  const total = +c.total || 0;
                  const called = total - (+c.pending || 0) - (+c.calling || 0);
                  const pct = total ? Math.round(called / total * 100) : 0;
                  return (
                    <Card key={c.id}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
                        <div>
                          <div style={{ fontWeight: 800, fontSize: 17, color: '#F1F5F9' }}>{c.name}</div>
                          <div style={{ color: '#4B6380', fontSize: 12, marginTop: 5, display: 'flex', gap: 16 }}>
                            <span>🎵 {c.audio_file}</span>
                            <span>🔁 макс. {c.max_retries} попытки</span>
                            <span>🕐 {c.time_from?.slice(0,5)}–{c.time_to?.slice(0,5)}</span>
                            <span>📞 {c.caller_id}</span>
                          </div>
                        </div>
                        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                          <Badge status={c.status} />
                          {c.status !== 'done' && (
                            <button onClick={() => handleToggle(c)} style={{
                              ...smallBtn, width: 'auto', padding: '5px 14px',
                              color: c.status === 'active' ? '#FCD34D' : '#4ADE80',
                              borderColor: c.status === 'active' ? '#92400E' : '#166534',
                              background: c.status === 'active' ? '#2D1B00' : '#052E16',
                            }}>
                              {c.status === 'active' ? '⏸ Пауза' : '▶ Запуск'}
                            </button>
                          )}
                        </div>
                      </div>

                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 16, marginBottom: 20 }}>
                        {[
                          { label: 'Всего', val: fmt.num(total), c: '#94A3B8' },
                          { label: 'Обзвонили', val: fmt.num(called), c: '#60A5FA' },
                          { label: 'Ответили', val: fmt.num(c.answered), c: '#4ADE80' },
                          { label: 'Не ответили', val: fmt.num(c.failed), c: '#F87171' },
                        ].map(s => (
                          <div key={s.label}>
                            <div style={{ color: s.c, fontWeight: 900, fontSize: 26, fontFamily: 'Georgia,serif' }}>{s.val}</div>
                            <div style={{ color: '#4B6380', fontSize: 11, marginTop: 2 }}>{s.label}</div>
                          </div>
                        ))}
                      </div>

                      <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                          <span style={{ color: '#4B6380', fontSize: 11 }}>Прогресс обзвона</span>
                          <span style={{ color: '#94A3B8', fontWeight: 800, fontSize: 11 }}>{pct}%</span>
                        </div>
                        <div style={{ height: 6, background: '#1A2D45', borderRadius: 4 }}>
                          <div style={{ width: `${pct}%`, height: '100%', background: 'linear-gradient(90deg,#4ADE80,#60A5FA)', borderRadius: 4, transition: 'width .6s' }} />
                        </div>
                      </div>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ── Calls ──────────────────────────────────────────────── */}
        {!loading && tab === 'calls' && (
          <div>
            <div style={{ marginBottom: 24, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <h1 style={{ fontSize: 22, fontWeight: 900, color: '#F1F5F9' }}>Журнал звонков</h1>
                <div style={{ color: '#4B6380', fontSize: 13, marginTop: 4 }}>{fmt.num(calls.length)} записей</div>
              </div>
              <button onClick={loadAll} style={{ ...smallBtn, width: 'auto', padding: '7px 16px', color: '#60A5FA', borderColor: '#1D4ED840' }}>
                ⟳ Обновить
              </button>
            </div>
            <Card style={{ padding: 0 }}>
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                  <thead>
                    <tr style={{ borderBottom: '1px solid #1A2D45' }}>
                      {['Время', 'Телефон', 'Имя', 'Кампания', 'Статус', 'Попытка', 'Длительность', 'DTMF'].map(h => (
                        <th key={h} style={{ textAlign: 'left', padding: '14px 20px', color: '#4B6380', fontSize: 10, fontWeight: 800, letterSpacing: 1, whiteSpace: 'nowrap' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {calls.length === 0 && (
                      <tr><td colSpan={8} style={{ textAlign: 'center', padding: 40, color: '#2A4060' }}>Нет звонков</td></tr>
                    )}
                    {calls.map(call => (
                      <tr key={call.id} style={{ borderBottom: '1px solid #0C1929' }}
                        onMouseEnter={e => e.currentTarget.style.background = '#0C1929'}
                        onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                        <td style={{ padding: '12px 20px', color: '#4B6380', whiteSpace: 'nowrap' }}>{fmt.time(call.started_at)}</td>
                        <td style={{ padding: '12px 20px', color: '#CBD5E1', fontFamily: 'monospace', fontWeight: 600 }}>{call.phone}</td>
                        <td style={{ padding: '12px 20px', color: '#94A3B8' }}>{call.contact_name || '—'}</td>
                        <td style={{ padding: '12px 20px', color: '#64748B', fontSize: 12 }}>{call.campaign_name}</td>
                        <td style={{ padding: '12px 20px' }}><Badge status={call.status} /></td>
                        <td style={{ padding: '12px 20px', color: '#4B6380', textAlign: 'center' }}>#{call.attempt}</td>
                        <td style={{ padding: '12px 20px', color: call.duration ? '#4ADE80' : '#4B6380' }}>
                          {call.duration ? fmt.dur(call.duration) : '—'}
                        </td>
                        <td style={{ padding: '12px 20px' }}>
                          {call.dtmf_pressed ? (
                            <span style={{ background: '#1D4ED820', border: '1px solid #1D4ED8', color: '#60A5FA', borderRadius: 6, padding: '2px 8px', fontWeight: 800, fontSize: 13 }}>
                              [{call.dtmf_pressed}]
                            </span>
                          ) : '—'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {/* ── Audio ──────────────────────────────────────────────── */}
        {!loading && tab === 'audio' && (
          <div>
            <h1 style={{ fontSize: 22, fontWeight: 900, color: '#F1F5F9', marginBottom: 24 }}>Аудио файлы</h1>

            <Card style={{ marginBottom: 20 }}>
              <SectionTitle>Загрузить новый файл</SectionTitle>
              <div style={{ display: 'flex', gap: 12, alignItems: 'flex-end', flexWrap: 'wrap' }}>
                <div style={{ flex: 2 }}>
                  <Field label="Файл (WAV, MP3, GSM)">
                    <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                      <input ref={fileInputRef} type="file" accept=".wav,.mp3,.gsm,.ulaw,.alaw" style={{ display: 'none' }}
                        onChange={e => setUploadFile(e.target.files[0])} />
                      <button onClick={() => fileInputRef.current.click()} style={{ ...smallBtn, width: 'auto', padding: '7px 16px' }}>
                        📂 Выбрать файл
                      </button>
                      {uploadFile && <span style={{ color: '#4ADE80', fontSize: 12 }}>✓ {uploadFile.name}</span>}
                    </div>
                  </Field>
                </div>
                <div style={{ flex: 2 }}>
                  <Field label="Название (для интерфейса)">
                    <Input value={uploadLabel} onChange={setUploadLabel} placeholder="Например: Акция июнь" />
                  </Field>
                </div>
                <Btn onClick={handleUploadAudio} color="#166534" style={{ whiteSpace: 'nowrap' }}>
                  {uploading ? '⏳' : '↑ Загрузить'}
                </Btn>
              </div>
              <div style={{ color: '#4B6380', fontSize: 11, marginTop: 10 }}>
                Файлы сохраняются в /var/lib/asterisk/sounds/autodialer/. MP3 конвертируется в WAV автоматически (требует sox).
              </div>
            </Card>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px,1fr))', gap: 16 }}>
              {audioFiles.map(f => (
                <Card key={f.filename} style={{ padding: 18 }}>
                  <div style={{ fontSize: 24, marginBottom: 10 }}>🎵</div>
                  <div style={{ fontWeight: 700, fontSize: 14, color: '#F1F5F9' }}>{f.label}</div>
                  <div style={{ color: '#4B6380', fontSize: 11, marginTop: 4, fontFamily: 'monospace' }}>{f.filename}</div>
                  {f.duration && <div style={{ color: '#64748B', fontSize: 11, marginTop: 2 }}>⏱ {fmt.dur(f.duration)}</div>}
                </Card>
              ))}
              {!audioFiles.length && (
                <div style={{ color: '#2A4060', gridColumn: '1/-1', textAlign: 'center', padding: 40 }}>Нет загруженных файлов</div>
              )}
            </div>
          </div>
        )}

        {/* ── Analytics ──────────────────────────────────────────── */}
        {!loading && tab === 'analytics' && (
          <div>
            <h1 style={{ fontSize: 22, fontWeight: 900, color: '#F1F5F9', marginBottom: 24 }}>Аналитика</h1>
            <Analytics data={analytics} />
          </div>
        )}
      </div>

      {showNew && <NewCampaignModal audioFiles={audioFiles} onClose={() => setShowNew(false)} onSaved={loadAll} />}
    </div>
  );
}
