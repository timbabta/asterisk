# 🚀 AutoDial — Инструкция по установке
## Система автопрозвонки на Asterisk 13 + MySQL + PHP

---

## Требования
- Ubuntu 22.04
- Asterisk 13 (уже установлен)
- MySQL (уже установлен)
- PHP 8.x + Apache/Nginx
- PHP расширения: pdo_mysql, curl, json

---

## ШАГ 1 — Установка зависимостей

```bash
# Обновляем систему
sudo apt update && sudo apt upgrade -y

# PHP и расширения
sudo apt install -y php php-mysql php-curl php-json php-mbstring

# Apache (если ещё не стоит)
sudo apt install -y apache2

# Sox для конвертации MP3 → WAV
sudo apt install -y sox libsox-fmt-mp3

# Включаем mod_rewrite
sudo a2enmod rewrite
sudo systemctl restart apache2
```

---

## ШАГ 2 — База данных MySQL

```bash
# Входим в MySQL
mysql -u root -p

# Создаём пользователя и даём права
CREATE USER 'autodialer_user'@'localhost' IDENTIFIED BY 'StrongPassword123';
GRANT ALL PRIVILEGES ON autodialer.* TO 'autodialer_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;

# Применяем схему
mysql -u root -p < /var/www/autodialer/sql/schema.sql
```

---

## ШАГ 3 — Копируем файлы проекта

```bash
# Создаём директорию проекта
sudo mkdir -p /var/www/autodialer

# Копируем все файлы (предполагается что архив в /tmp/autodialer)
sudo cp -r /tmp/autodialer/* /var/www/autodialer/

# Создаём папку для аудио файлов
sudo mkdir -p /var/lib/asterisk/sounds/autodialer
sudo chown asterisk:asterisk /var/lib/asterisk/sounds/autodialer

# Права на файлы
sudo chown -R www-data:www-data /var/www/autodialer
sudo chmod -R 755 /var/www/autodialer
```

---

## ШАГ 4 — Настройка config.php

```bash
sudo nano /var/www/autodialer/api/config.php
```

Обязательно измените:
- `DB_PASS` — пароль к MySQL
- `ASTERISK_CHANNEL` — ваш транк (например `SIP/mtt` или `DAHDI/g1`)
- `DEFAULT_CALLERID` — ваш номер телефона

---

## ШАГ 5 — Apache конфигурация

```bash
sudo nano /etc/apache2/sites-available/autodialer.conf
```

Вставьте:
```apache
<VirtualHost *:80>
    ServerName autodialer.local
    DocumentRoot /var/www/autodialer/frontend/public

    # API — PHP
    Alias /autodialer/api /var/www/autodialer/api

    <Directory /var/www/autodialer/api>
        AllowOverride All
        Require all granted
        Options -Indexes
    </Directory>

    <Directory /var/www/autodialer/frontend/public>
        AllowOverride All
        Require all granted
        Options -Indexes
    </Directory>

    ErrorLog ${APACHE_LOG_DIR}/autodialer_error.log
    CustomLog ${APACHE_LOG_DIR}/autodialer_access.log combined
</VirtualHost>
```

```bash
sudo a2ensite autodialer
sudo systemctl reload apache2
```

---

## ШАГ 6 — Frontend (React → статический HTML)

```bash
# Устанавливаем Node.js (если нет)
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# В папке frontend
cd /var/www/autodialer/frontend
npm create vite@latest . -- --template react
# Выбираем: React → JavaScript

# Копируем App.jsx поверх созданного
cp /var/www/autodialer/frontend/App.jsx src/App.jsx

# Устанавливаем и собираем
npm install
npm run build

# Собранные файлы будут в dist/
# Копируем в public
cp -r dist/* public/
```

Или просто используйте встроенный dev-сервер для разработки:
```bash
npm run dev
# Открывайте http://localhost:5173
```

---

## ШАГ 7 — Asterisk диалплан

```bash
# Копируем конфиг
sudo cp /var/www/autodialer/asterisk/extensions_autodialer.conf /etc/asterisk/

# Добавляем include в основной extensions.conf
sudo nano /etc/asterisk/extensions.conf
```

В конец файла добавьте:
```ini
#include extensions_autodialer.conf
```

---

## ШАГ 8 — AGI скрипты

```bash
# Копируем AGI скрипты
sudo cp /var/www/autodialer/asterisk/autodialer.agi /var/lib/asterisk/agi-bin/
sudo cp /var/www/autodialer/asterisk/cdr_handler.agi /var/lib/asterisk/agi-bin/

# Права на выполнение
sudo chmod +x /var/lib/asterisk/agi-bin/autodialer.agi
sudo chmod +x /var/lib/asterisk/agi-bin/cdr_handler.agi
sudo chown asterisk:asterisk /var/lib/asterisk/agi-bin/autodialer.agi
sudo chown asterisk:asterisk /var/lib/asterisk/agi-bin/cdr_handler.agi

# В конфиге AGI пути к config.php — проверьте:
# /var/www/autodialer/api/config.php
```

Добавьте в диалплан обработку неотвеченных:
```ini
; В extensions_autodialer.conf, в контексте [autodialer-ivr]:
exten => h,1,AGI(cdr_handler.agi)
```

---

## ШАГ 9 — Перезагружаем Asterisk

```bash
sudo asterisk -rx "dialplan reload"
sudo asterisk -rx "module reload"
```

---

## ШАГ 10 — Cron для воркера

```bash
# Добавляем задание (каждую минуту)
sudo crontab -e
```

Добавьте строку:
```cron
* * * * * /usr/bin/php /var/www/autodialer/worker/worker.php >> /var/log/autodialer.log 2>&1
```

---

## ШАГ 11 — Права для воркера

```bash
# Воркер должен иметь право писать в spool Asterisk
# Добавляем www-data в группу asterisk
sudo usermod -aG asterisk www-data

# Права на spool
sudo chmod 775 /var/spool/asterisk/outgoing
sudo chown asterisk:asterisk /var/spool/asterisk/outgoing

# Для cron — запускаем от пользователя asterisk:
# sudo crontab -u asterisk -e
# * * * * * /usr/bin/php /var/www/autodialer/worker/worker.php >> /var/log/autodialer_worker.log 2>&1
```

---

## ШАГ 12 — Тестирование

```bash
# Проверяем API
curl http://localhost/autodialer/api/index.php?route=campaigns

# Проверяем воркер вручную
sudo -u asterisk php /var/www/autodialer/worker/worker.php

# Смотрим логи
tail -f /var/log/autodialer_worker.log
tail -f /var/log/asterisk/autodialer_agi.log
tail -f /var/log/asterisk/full
```

---

## Порядок работы с системой

1. **Загрузите аудио файлы** → вкладка "Аудио"
2. **Создайте кампанию** → "+ Новая кампания"
   - Шаг 1: название, аудио, попытки, время
   - Шаг 2: номера телефонов
   - Шаг 3: IVR логика (необязательно)
3. **Нажмите "Запуск"** → воркер начнёт звонить каждую минуту
4. **Следите за результатами** → вкладки "Звонки" и "Аналитика"

---

## Структура файлов

```
/var/www/autodialer/
├── api/
│   ├── config.php          ← НАСТРОЙКИ (отредактируйте!)
│   ├── index.php           ← Роутер API
│   ├── campaigns.php       ← Кампании
│   ├── contacts.php        ← Номера телефонов
│   ├── calls.php           ← Журнал + webhook
│   ├── audio.php           ← Аудио файлы
│   ├── analytics.php       ← Статистика
│   └── ivr.php             ← Сохранение IVR
├── worker/
│   └── worker.php          ← Запускается cron каждую минуту
├── asterisk/
│   ├── extensions_autodialer.conf  ← Диалплан Asterisk
│   ├── autodialer.agi              ← AGI: логика звонка
│   └── cdr_handler.agi             ← AGI: фиксация результата
├── sql/
│   └── schema.sql          ← Схема базы данных
└── frontend/
    ├── App.jsx             ← React приложение
    └── public/             ← Собранный фронтенд
```

---

## Частые проблемы

**Звонки не создаются:**
```bash
# Проверьте права на spool
ls -la /var/spool/asterisk/outgoing
# Должно быть: drwxrwxr-x asterisk asterisk
```

**Ошибка в AGI:**
```bash
tail -f /var/log/asterisk/autodialer_agi.log
```

**API отдаёт ошибку БД:**
```bash
# Проверьте config.php — DB_USER, DB_PASS, DB_NAME
php -r "require '/var/www/autodialer/api/config.php'; getDB(); echo 'OK';"
```

**Asterisk не видит диалплан:**
```bash
asterisk -rx "dialplan show autodialer-ivr"
```
