#!/usr/bin/env php
<?php
// ============================================================
// worker.php — воркер автопрозвонки
// Запускается каждую минуту через cron:
//   * * * * * /usr/bin/php /var/www/autodialer/worker/worker.php >> /var/log/autodialer.log 2>&1
// ============================================================

require_once __DIR__ . '/../api/config.php';

$db     = getDB();
$now    = date('H:i:s');
$nowTs  = time();

echo "[" . date('Y-m-d H:i:s') . "] Worker started\n";

// ── Ищем активные кампании в рабочее время ──────────────────
$campaigns = $db->query("
    SELECT * FROM campaigns
    WHERE status = 'active'
      AND time_from <= '$now'
      AND time_to   >= '$now'
")->fetchAll();

if (!$campaigns) {
    echo "No active campaigns in working hours.\n";
    exit;
}

foreach ($campaigns as $campaign) {
    echo "Processing campaign #{$campaign['id']}: {$campaign['name']}\n";

    // Ищем контакты для звонка:
    // - статус pending
    // - ещё не достигли максимума попыток
    // - либо ни разу не звонили, либо прошло достаточно времени (retry_delay)
    $stmt = $db->prepare("
        SELECT * FROM contacts
        WHERE campaign_id = ?
          AND status = 'pending'
          AND attempts < ?
          AND (
              last_called IS NULL
              OR last_called <= DATE_SUB(NOW(), INTERVAL ? SECOND)
          )
        LIMIT 10
    ");
    $stmt->execute([
        $campaign['id'],
        $campaign['max_retries'],
        $campaign['retry_delay'],
    ]);
    $contacts = $stmt->fetchAll();

    if (!$contacts) {
        echo "  No contacts to call.\n";
        continue;
    }

    foreach ($contacts as $contact) {
        echo "  Calling {$contact['phone']} (attempt " . ($contact['attempts'] + 1) . ")...\n";

        // Помечаем как "в процессе" чтобы не выбрать снова
        $db->prepare("UPDATE contacts SET status = 'calling' WHERE id = ?")
           ->execute([$contact['id']]);

        // Создаём .call файл для Asterisk
        $callFile = createCallFile($campaign, $contact);
        if ($callFile) {
            echo "  Created call file: $callFile\n";
        } else {
            echo "  ERROR: Failed to create call file!\n";
            // Откатываем статус
            $db->prepare("UPDATE contacts SET status = 'pending' WHERE id = ?")
               ->execute([$contact['id']]);
        }
    }
}

echo "[" . date('Y-m-d H:i:s') . "] Worker done\n";

// ── Функция создания .call файла ────────────────────────────
function createCallFile(array $campaign, array $contact): string|false
{
    $phone     = $contact['phone'];
    $cid       = $campaign['caller_id'];
    $channel   = ASTERISK_CHANNEL . '/' . $phone;
    $context   = ASTERISK_CONTEXT;
    $attempt   = $contact['attempts'] + 1;
    $uid       = uniqid('ad_', true);

    // Временное имя (с точкой — Asterisk не читает пока пишем)
    $tmpFile  = ASTERISK_SPOOL . '/.' . $uid . '.call';
    $destFile = ASTERISK_SPOOL . '/' . $uid . '.call';

    $content = implode("\n", [
        "Channel: $channel",
        "CallerID: <$cid>",
        "MaxRetries: 1",          // Asterisk-уровень: 1 попытка, остальные — наш воркер
        "RetryTime: 60",
        "WaitTime: 45",           // Ждать ответа 45 секунд
        "Context: $context",
        "Extension: s",
        "Priority: 1",
        "Set: AUTODIALER_CONTACT_ID={$contact['id']}",
        "Set: AUTODIALER_CAMPAIGN_ID={$campaign['id']}",
        "Set: AUTODIALER_AUDIO={$campaign['audio_file']}",
        "Set: AUTODIALER_ATTEMPT=$attempt",
        "Set: AUTODIALER_IVR_PLAN=" . urlencode($campaign['ivr_plan'] ?? '{}'),
        "",
    ]);

    if (file_put_contents($tmpFile, $content) === false) {
        return false;
    }

    // Меняем владельца на asterisk
    chown($tmpFile, ASTERISK_USER);
    chgrp($tmpFile, ASTERISK_USER);

    // Атомарно перемещаем — Asterisk подхватит файл
    rename($tmpFile, $destFile);

    return $destFile;
}
