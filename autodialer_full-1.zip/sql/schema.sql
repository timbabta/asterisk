-- ============================================================
-- AutoDial — схема базы данных
-- Запуск: mysql -u root -p autodialer < schema.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS autodialer CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE autodialer;

-- ── Кампании ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS campaigns (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(255)    NOT NULL,
    status      ENUM('draft','active','paused','done') DEFAULT 'draft',
    audio_file  VARCHAR(255)    NOT NULL COMMENT 'Имя .wav файла в /var/lib/asterisk/sounds/autodialer/',
    ivr_plan    JSON            NULL     COMMENT 'JSON-схема IVR логики',
    max_retries TINYINT         NOT NULL DEFAULT 3,
    retry_delay INT             NOT NULL DEFAULT 300  COMMENT 'Секунды между попытками',
    time_from   TIME            NOT NULL DEFAULT '09:00:00',
    time_to     TIME            NOT NULL DEFAULT '20:00:00',
    caller_id   VARCHAR(50)     NOT NULL DEFAULT '70000000000',
    created_at  DATETIME        DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME        DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ── Контакты / номера телефонов ─────────────────────────────
CREATE TABLE IF NOT EXISTS contacts (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    campaign_id INT             NOT NULL,
    phone       VARCHAR(20)     NOT NULL COMMENT 'В формате 79991234567',
    name        VARCHAR(255)    NULL,
    status      ENUM('pending','calling','answered','failed','max_retries') DEFAULT 'pending',
    attempts    TINYINT         NOT NULL DEFAULT 0,
    last_called DATETIME        NULL,
    answered_at DATETIME        NULL,
    created_at  DATETIME        DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE CASCADE,
    INDEX idx_campaign_status (campaign_id, status),
    INDEX idx_last_called (last_called)
);

-- ── Журнал звонков ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS call_log (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    contact_id   INT             NOT NULL,
    campaign_id  INT             NOT NULL,
    phone        VARCHAR(20)     NOT NULL,
    attempt      TINYINT         NOT NULL DEFAULT 1,
    status       ENUM('initiated','answered','no_answer','busy','failed','congestion') DEFAULT 'initiated',
    duration     INT             NOT NULL DEFAULT 0 COMMENT 'Секунды',
    dtmf_pressed VARCHAR(10)     NULL     COMMENT 'Какую клавишу нажал клиент',
    started_at   DATETIME        DEFAULT CURRENT_TIMESTAMP,
    ended_at     DATETIME        NULL,
    asterisk_uid VARCHAR(100)    NULL     COMMENT 'UniqueID из Asterisk',
    FOREIGN KEY (contact_id)  REFERENCES contacts(id)  ON DELETE CASCADE,
    FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE CASCADE,
    INDEX idx_campaign (campaign_id),
    INDEX idx_started  (started_at)
);

-- ── Аудио файлы ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audio_files (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    filename    VARCHAR(255)    NOT NULL UNIQUE,
    label       VARCHAR(255)    NOT NULL,
    duration    INT             NULL COMMENT 'Секунды',
    created_at  DATETIME        DEFAULT CURRENT_TIMESTAMP
);

-- ── Начальные данные ─────────────────────────────────────────
INSERT IGNORE INTO audio_files (filename, label) VALUES
('welcome',      'Приветствие'),
('promo_may',    'Акция май'),
('debt_notice',  'Уведомление о долге'),
('survey',       'Опрос клиентов'),
('press1',       'Нажмите 1'),
('press2',       'Нажмите 2'),
('goodbye',      'До свидания'),
('operator',     'Перевод на оператора');

-- Пример кампании
INSERT IGNORE INTO campaigns (id, name, status, audio_file, max_retries, caller_id, ivr_plan) VALUES
(1, 'Тестовая кампания', 'draft', 'welcome', 3, '70000000000',
 '{"nodes":[{"id":1,"type":"play","audio":"welcome","next":2},{"id":2,"type":"menu","options":{"1":{"label":"Акция","audio":"promo_may","next":null},"2":{"label":"Оператор","transfer":"100","next":null},"9":{"label":"Выход","hangup":true}}}]}');
