#!/bin/bash
# ============================================================
# AutoDial — скрипт автоустановки
# Запуск: sudo bash install.sh
# ============================================================

set -e  # Остановиться при любой ошибке

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

INSTALL_DIR="/var/www/autodialer"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

log()    { echo -e "${GREEN}[✓]${NC} $1"; }
warn()   { echo -e "${YELLOW}[!]${NC} $1"; }
error()  { echo -e "${RED}[✗]${NC} $1"; exit 1; }
step()   { echo -e "\n${CYAN}══════════════════════════════════════${NC}"; echo -e "${BLUE}[→]${NC} $1"; echo -e "${CYAN}══════════════════════════════════════${NC}"; }

# ── Проверка root ────────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
   error "Запустите скрипт от root: sudo bash install.sh"
fi

echo ""
echo -e "${CYAN}"
echo "  ╔═══════════════════════════════════╗"
echo "  ║     AutoDial — Автоустановка      ║"
echo "  ║  Asterisk 13 + MySQL + PHP + React ║"
echo "  ╚═══════════════════════════════════╝"
echo -e "${NC}"

# ── Запрашиваем параметры ────────────────────────────────────
echo -e "${YELLOW}Настройка параметров:${NC}"
echo ""

read -p "  MySQL root пароль: " -s MYSQL_ROOT_PASS; echo
read -p "  Пароль для пользователя autodialer_user [AutoDial2024!]: " DB_PASS
DB_PASS=${DB_PASS:-AutoDial2024!}

read -p "  Asterisk канал (например SIP/provider или DAHDI/g1) [SIP/provider]: " AST_CHANNEL
AST_CHANNEL=${AST_CHANNEL:-SIP/provider}

read -p "  Ваш номер телефона (CallerID) [70000000000]: " CALLER_ID
CALLER_ID=${CALLER_ID:-70000000000}

read -p "  Домен/IP сервера [localhost]: " SERVER_HOST
SERVER_HOST=${SERVER_HOST:-localhost}

echo ""
warn "Начинаем установку... Это займёт 2-5 минут."
echo ""

# ── ШАГ 1: Пакеты ────────────────────────────────────────────
step "Шаг 1/10: Установка системных пакетов"

apt-get update -qq
apt-get install -y -qq \
    php php-mysql php-curl php-json php-mbstring php-cli \
    apache2 \
    sox libsox-fmt-mp3 \
    curl wget unzip \
    nodejs npm 2>/dev/null || true

# Node.js >= 18
NODE_VER=$(node -v 2>/dev/null | sed 's/v//' | cut -d. -f1)
if [[ -z "$NODE_VER" ]] || [[ "$NODE_VER" -lt 18 ]]; then
    warn "Устанавливаем Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash - >/dev/null 2>&1
    apt-get install -y -qq nodejs
fi

a2enmod rewrite >/dev/null 2>&1
log "Пакеты установлены"

# ── ШАГ 2: MySQL ─────────────────────────────────────────────
step "Шаг 2/10: Настройка MySQL"

mysql -u root -p"$MYSQL_ROOT_PASS" -e "
    CREATE DATABASE IF NOT EXISTS autodialer CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
    CREATE USER IF NOT EXISTS 'autodialer_user'@'localhost' IDENTIFIED BY '$DB_PASS';
    GRANT ALL PRIVILEGES ON autodialer.* TO 'autodialer_user'@'localhost';
    FLUSH PRIVILEGES;
" 2>/dev/null || error "Ошибка подключения к MySQL. Проверьте root пароль."

mysql -u autodialer_user -p"$DB_PASS" autodialer < "$SCRIPT_DIR/sql/schema.sql" 2>/dev/null
log "База данных создана"

# ── ШАГ 3: Копируем файлы ────────────────────────────────────
step "Шаг 3/10: Копирование файлов проекта"

mkdir -p "$INSTALL_DIR"
cp -r "$SCRIPT_DIR"/* "$INSTALL_DIR/"
chown -R www-data:www-data "$INSTALL_DIR"
chmod -R 755 "$INSTALL_DIR"
log "Файлы скопированы в $INSTALL_DIR"

# ── ШАГ 4: config.php ────────────────────────────────────────
step "Шаг 4/10: Генерация config.php"

cat > "$INSTALL_DIR/api/config.php" << PHPEOF
<?php
// Автоматически сгенерировано install.sh $(date)

define('DB_HOST', 'localhost');
define('DB_NAME', 'autodialer');
define('DB_USER', 'autodialer_user');
define('DB_PASS', '$DB_PASS');

define('ASTERISK_SPOOL',  '/var/spool/asterisk/outgoing');
define('ASTERISK_SOUNDS', '/var/lib/asterisk/sounds/autodialer');
define('ASTERISK_CHANNEL', '$AST_CHANNEL');
define('ASTERISK_CONTEXT', 'autodialer-ivr');
define('DEFAULT_CALLERID', '$CALLER_ID');
define('ASTERISK_USER',   'asterisk');
define('API_BASE_URL',    'http://$SERVER_HOST/autodialer/api/index.php');

function getDB(): PDO {
    static \$pdo = null;
    if (\$pdo === null) {
        \$pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER, DB_PASS,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]
        );
    }
    return \$pdo;
}

function jsonResponse(mixed \$data, int \$code = 200): void {
    http_response_code(\$code);
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    if (\$_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;
    echo json_encode(\$data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function getBody(): array {
    return json_decode(file_get_contents('php://input'), true) ?? [];
}
PHPEOF

log "config.php сгенерирован"

# ── ШАГ 5: Аудио директория ──────────────────────────────────
step "Шаг 5/10: Настройка директорий Asterisk"

mkdir -p /var/lib/asterisk/sounds/autodialer
chown asterisk:asterisk /var/lib/asterisk/sounds/autodialer
chmod 775 /var/lib/asterisk/sounds/autodialer

# Права на spool
chmod 775 /var/spool/asterisk/outgoing
chown asterisk:asterisk /var/spool/asterisk/outgoing

# www-data в группу asterisk (для записи call файлов)
usermod -aG asterisk www-data 2>/dev/null || true

# Создаём тестовый silence.wav (если sox доступен)
if command -v sox &>/dev/null; then
    sox -n -r 8000 -c 1 /var/lib/asterisk/sounds/autodialer/silence.wav trim 0.0 2.0 2>/dev/null || true
    chown asterisk:asterisk /var/lib/asterisk/sounds/autodialer/silence.wav 2>/dev/null || true
fi

log "Директории настроены"

# ── ШАГ 6: AGI скрипты ───────────────────────────────────────
step "Шаг 6/10: Установка AGI скриптов"

cp "$INSTALL_DIR/asterisk/autodialer.agi" /var/lib/asterisk/agi-bin/
cp "$INSTALL_DIR/asterisk/cdr_handler.agi" /var/lib/asterisk/agi-bin/

chmod +x /var/lib/asterisk/agi-bin/autodialer.agi
chmod +x /var/lib/asterisk/agi-bin/cdr_handler.agi
chown asterisk:asterisk /var/lib/asterisk/agi-bin/autodialer.agi
chown asterisk:asterisk /var/lib/asterisk/agi-bin/cdr_handler.agi

# Обновляем путь к config.php в AGI скриптах
sed -i "s|/var/www/autodialer/api/config.php|$INSTALL_DIR/api/config.php|g" \
    /var/lib/asterisk/agi-bin/autodialer.agi \
    /var/lib/asterisk/agi-bin/cdr_handler.agi

# Обновляем URL API в AGI
sed -i "s|http://localhost/autodialer/api/index.php|http://$SERVER_HOST/autodialer/api/index.php|g" \
    /var/lib/asterisk/agi-bin/autodialer.agi \
    /var/lib/asterisk/agi-bin/cdr_handler.agi

log "AGI скрипты установлены"

# ── ШАГ 7: Asterisk диалплан ─────────────────────────────────
step "Шаг 7/10: Настройка диалплана Asterisk"

cp "$INSTALL_DIR/asterisk/extensions_autodialer.conf" /etc/asterisk/

# Добавляем include если ещё нет
if ! grep -q "extensions_autodialer.conf" /etc/asterisk/extensions.conf 2>/dev/null; then
    echo "" >> /etc/asterisk/extensions.conf
    echo "; AutoDial" >> /etc/asterisk/extensions.conf
    echo "#include extensions_autodialer.conf" >> /etc/asterisk/extensions.conf
    log "Добавлен #include в extensions.conf"
else
    warn "Include уже есть в extensions.conf"
fi

# Перезагружаем диалплан
asterisk -rx "dialplan reload" >/dev/null 2>&1 && log "Диалплан перезагружен" || warn "Не удалось перезагрузить диалплан (Asterisk не запущен?)"

# ── ШАГ 8: Apache ────────────────────────────────────────────
step "Шаг 8/10: Настройка Apache"

cat > /etc/apache2/sites-available/autodialer.conf << APACHEEOF
<VirtualHost *:80>
    ServerName $SERVER_HOST
    DocumentRoot $INSTALL_DIR/frontend/public

    Alias /autodialer/api $INSTALL_DIR/api
    Alias /autodialer $INSTALL_DIR/frontend/public

    <Directory $INSTALL_DIR/api>
        AllowOverride All
        Require all granted
        Options -Indexes
        php_flag display_errors Off
        php_value error_reporting 0
    </Directory>

    <Directory $INSTALL_DIR/frontend/public>
        AllowOverride All
        Require all granted
        Options -Indexes
        FallbackResource /autodialer/index.html
    </Directory>

    <FilesMatch "\.php$">
        SetHandler application/x-httpd-php
    </FilesMatch>

    ErrorLog \${APACHE_LOG_DIR}/autodialer_error.log
    CustomLog \${APACHE_LOG_DIR}/autodialer_access.log combined
</VirtualHost>
APACHEEOF

a2ensite autodialer >/dev/null 2>&1
systemctl reload apache2
log "Apache настроен"

# ── ШАГ 9: Frontend сборка ───────────────────────────────────
step "Шаг 9/10: Сборка React frontend"

mkdir -p "$INSTALL_DIR/frontend/public"
cd /tmp

# Создаём временный vite проект
rm -rf /tmp/autodialer_build
mkdir /tmp/autodialer_build
cd /tmp/autodialer_build

npm create vite@latest . -- --template react --yes >/dev/null 2>&1 || \
    (npm init -y >/dev/null 2>&1 && npm install vite @vitejs/plugin-react >/dev/null 2>&1)

npm install >/dev/null 2>&1

# Копируем наш App.jsx
cp "$INSTALL_DIR/frontend/App.jsx" src/App.jsx

# Обновляем main.jsx
cat > src/main.jsx << 'MAINEOF'
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
ReactDOM.createRoot(document.getElementById('root')).render(<React.StrictMode><App /></React.StrictMode>)
MAINEOF

# index.html
cat > index.html << HTMLEOF
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>AutoDial — Автопрозвонка</title>
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>📡</text></svg>"/>
</head>
<body style="margin:0;background:#060E1A">
  <div id="root"></div>
  <script type="module" src="/src/main.jsx"></script>
</body>
</html>
HTMLEOF

# vite.config.js с базовым путём
cat > vite.config.js << 'VITEEOF'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
export default defineConfig({
  plugins: [react()],
  base: '/autodialer/',
})
VITEEOF

npm run build >/dev/null 2>&1

# Копируем собранный фронт
cp -r dist/* "$INSTALL_DIR/frontend/public/"
chown -R www-data:www-data "$INSTALL_DIR/frontend/public"

cd /
rm -rf /tmp/autodialer_build
log "Frontend собран и скопирован"

# ── ШАГ 10: Cron воркер ──────────────────────────────────────
step "Шаг 10/10: Настройка cron воркера"

CRON_LINE="* * * * * /usr/bin/php $INSTALL_DIR/worker/worker.php >> /var/log/autodialer_worker.log 2>&1"

# Добавляем в crontab asterisk если нет
(crontab -u asterisk -l 2>/dev/null | grep -v "autodialer"; echo "$CRON_LINE") | crontab -u asterisk -

# Создаём файл лога
touch /var/log/autodialer_worker.log
chown asterisk:asterisk /var/log/autodialer_worker.log

touch /var/log/asterisk/autodialer_agi.log
touch /var/log/asterisk/autodialer_cdr.log
chown asterisk:asterisk /var/log/asterisk/autodialer_agi.log
chown asterisk:asterisk /var/log/asterisk/autodialer_cdr.log

log "Cron воркер настроен (каждую минуту)"

# ── Проверка API ──────────────────────────────────────────────
step "Проверка установки"

sleep 2
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost/autodialer/api/index.php?route=campaigns" 2>/dev/null || echo "000")

if [[ "$HTTP_CODE" == "200" ]]; then
    log "API отвечает корректно (HTTP 200)"
else
    warn "API вернул HTTP $HTTP_CODE — возможно нужна настройка (это нормально если Apache только запустился)"
fi

# ── Итог ─────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}"
echo "  ╔═══════════════════════════════════════════════════╗"
echo "  ║           ✅  Установка завершена!                ║"
echo "  ╚═══════════════════════════════════════════════════╝"
echo -e "${NC}"
echo ""
echo -e "  ${CYAN}Веб-интерфейс:${NC}  http://$SERVER_HOST/autodialer/"
echo -e "  ${CYAN}API:${NC}            http://$SERVER_HOST/autodialer/api/index.php?route=campaigns"
echo ""
echo -e "  ${YELLOW}Следующие шаги:${NC}"
echo "  1. Откройте веб-интерфейс в браузере"
echo "  2. Загрузите аудио файлы (вкладка Аудио)"
echo "  3. Создайте кампанию и добавьте номера"
echo "  4. Нажмите Запуск"
echo ""
echo -e "  ${YELLOW}Логи:${NC}"
echo "  tail -f /var/log/autodialer_worker.log"
echo "  tail -f /var/log/asterisk/autodialer_agi.log"
echo ""
echo -e "  ${YELLOW}Ваши параметры сохранены в:${NC}"
echo "  $INSTALL_DIR/api/config.php"
echo ""
