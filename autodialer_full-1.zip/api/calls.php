<?php
// ============================================================
// calls.php — журнал звонков + webhook от AGI скрипта
// ============================================================

$db   = getDB();
$body = getBody();
$id   = (int)($_GET['id'] ?? 0);

// ── GET — журнал звонков ─────────────────────────────────────
if ($method === 'GET') {
    $campaign_id = (int)($_GET['campaign_id'] ?? 0);
    $limit       = min((int)($_GET['limit'] ?? 100), 500);
    $offset      = (int)($_GET['offset'] ?? 0);

    $where = $campaign_id ? 'WHERE cl.campaign_id = ' . $campaign_id : '';

    $rows = $db->query("
        SELECT
            cl.*,
            ct.name  AS contact_name,
            ca.name  AS campaign_name
        FROM call_log cl
        LEFT JOIN contacts  ct ON ct.id  = cl.contact_id
        LEFT JOIN campaigns ca ON ca.id  = cl.campaign_id
        $where
        ORDER BY cl.started_at DESC
        LIMIT $limit OFFSET $offset
    ")->fetchAll();

    jsonResponse($rows);
}

// ── POST — webhook от AGI (Asterisk сообщает результат) ──────
if ($method === 'POST') {
    // Обязательные поля от AGI
    $required = ['contact_id', 'campaign_id', 'phone', 'status'];
    foreach ($required as $f) {
        if (empty($body[$f])) jsonResponse(['error' => "Field '$f' required"], 422);
    }

    $contactId  = (int)$body['contact_id'];
    $campaignId = (int)$body['campaign_id'];
    $status     = $body['status'];       // answered / no_answer / busy / failed / congestion
    $duration   = (int)($body['duration']   ?? 0);
    $dtmf       = $body['dtmf']         ?? null;
    $uid        = $body['asterisk_uid'] ?? null;
    $attempt    = (int)($body['attempt']    ?? 1);

    // Записываем в call_log
    $db->prepare('
        INSERT INTO call_log
            (contact_id, campaign_id, phone, attempt, status, duration, dtmf_pressed, ended_at, asterisk_uid)
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?)
    ')->execute([
        $contactId, $campaignId, $body['phone'],
        $attempt, $status, $duration, $dtmf, $uid
    ]);

    // Обновляем статус контакта
    $stmt = $db->prepare('SELECT * FROM contacts WHERE id = ?');
    $stmt->execute([$contactId]);
    $contact = $stmt->fetch();

    if ($contact) {
        $newAttempts = $contact['attempts'] + 1;

        if ($status === 'answered') {
            // Клиент ответил — больше не звоним
            $db->prepare('
                UPDATE contacts
                SET status = "answered", attempts = ?, answered_at = NOW(), last_called = NOW()
                WHERE id = ?
            ')->execute([$newAttempts, $contactId]);

        } elseif ($newAttempts >= $contact['max_retries'] ?? 3) {
            // Исчерпали попытки
            $db->prepare('
                UPDATE contacts
                SET status = "max_retries", attempts = ?, last_called = NOW()
                WHERE id = ?
            ')->execute([$newAttempts, $contactId]);

        } else {
            // Будем звонить ещё
            $db->prepare('
                UPDATE contacts
                SET status = "pending", attempts = ?, last_called = NOW()
                WHERE id = ?
            ')->execute([$newAttempts, $contactId]);
        }
    }

    // Проверяем, завершилась ли кампания
    $remaining = $db->prepare('
        SELECT COUNT(*) FROM contacts
        WHERE campaign_id = ? AND status = "pending"
    ');
    $remaining->execute([$campaignId]);
    if ((int)$remaining->fetchColumn() === 0) {
        $db->prepare('UPDATE campaigns SET status = "done" WHERE id = ? AND status = "active"')
           ->execute([$campaignId]);
    }

    jsonResponse(['message' => 'Call logged']);
}
