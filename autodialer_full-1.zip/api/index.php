<?php
// ============================================================
// index.php — главный роутер API
// Все запросы: /api/index.php?route=...
// ============================================================

require_once __DIR__ . '/config.php';

$route  = $_GET['route'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

// CORS preflight
if ($method === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    exit;
}

try {
    match (true) {
        // ── Кампании ──────────────────────────────────────
        $route === 'campaigns' && $method === 'GET'    => require __DIR__ . '/campaigns.php',
        $route === 'campaigns' && $method === 'POST'   => require __DIR__ . '/campaigns.php',
        $route === 'campaigns' && $method === 'PUT'    => require __DIR__ . '/campaigns.php',
        $route === 'campaigns' && $method === 'DELETE' => require __DIR__ . '/campaigns.php',

        // ── Контакты / номера ─────────────────────────────
        $route === 'contacts' && $method === 'GET'     => require __DIR__ . '/contacts.php',
        $route === 'contacts' && $method === 'POST'    => require __DIR__ . '/contacts.php',

        // ── Журнал звонков ────────────────────────────────
        $route === 'calls' && $method === 'GET'        => require __DIR__ . '/calls.php',
        $route === 'calls' && $method === 'POST'       => require __DIR__ . '/calls.php', // webhook от AGI

        // ── Аудио файлы ───────────────────────────────────
        $route === 'audio'   && $method === 'GET'      => require __DIR__ . '/audio.php',
        $route === 'audio'   && $method === 'POST'     => require __DIR__ . '/audio.php',

        // ── Аналитика ─────────────────────────────────────
        $route === 'analytics' && $method === 'GET'    => require __DIR__ . '/analytics.php',

        // ── IVR план ──────────────────────────────────────
        $route === 'ivr' && $method === 'POST'         => require __DIR__ . '/ivr.php',

        default => jsonResponse(['error' => 'Route not found: ' . $route], 404),
    };
} catch (Throwable $e) {
    jsonResponse(['error' => $e->getMessage(), 'trace' => $e->getTraceAsString()], 500);
}
