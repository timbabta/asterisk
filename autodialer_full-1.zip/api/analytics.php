<?php
// ============================================================
// analytics.php — статистика для дашборда
// ============================================================

$db = getDB();

// Звонки по дням (последние 7 дней)
$byDay = $db->query("
    SELECT
        DATE(started_at)          AS day,
        COUNT(*)                  AS total,
        SUM(status = 'answered')  AS answered,
        SUM(status != 'answered') AS failed
    FROM call_log
    WHERE started_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY DATE(started_at)
    ORDER BY day ASC
")->fetchAll();

// Общая статистика
$totals = $db->query("
    SELECT
        COUNT(*)                  AS total_calls,
        SUM(status = 'answered')  AS total_answered,
        SUM(status != 'answered') AS total_failed,
        AVG(NULLIF(duration, 0))  AS avg_duration
    FROM call_log
    WHERE started_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
")->fetch();

// По кампаниям
$byCampaign = $db->query("
    SELECT
        ca.id, ca.name,
        COUNT(cl.id)                  AS calls,
        SUM(cl.status = 'answered')   AS answered,
        SUM(cl.status != 'answered')  AS failed,
        ROUND(
            100.0 * SUM(cl.status = 'answered') / NULLIF(COUNT(cl.id), 0)
        , 1)                           AS conversion
    FROM campaigns ca
    LEFT JOIN call_log cl ON cl.campaign_id = ca.id
    GROUP BY ca.id
    ORDER BY calls DESC
")->fetchAll();

// DTMF нажатия
$dtmf = $db->query("
    SELECT dtmf_pressed AS key_, COUNT(*) AS cnt
    FROM call_log
    WHERE dtmf_pressed IS NOT NULL AND dtmf_pressed != ''
    GROUP BY dtmf_pressed
    ORDER BY cnt DESC
")->fetchAll();

jsonResponse([
    'by_day'       => $byDay,
    'totals'       => $totals,
    'by_campaign'  => $byCampaign,
    'dtmf'         => $dtmf,
]);
