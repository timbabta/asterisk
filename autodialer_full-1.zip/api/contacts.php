<?php
// ============================================================
// contacts.php
// ============================================================
// Этот файл подключается роутером, $db/$method/$body уже есть

$id = (int)($_GET['id'] ?? 0);
$campaign_id = (int)($_GET['campaign_id'] ?? 0);

if ($method === 'GET') {
    $where = $campaign_id ? 'WHERE campaign_id = ' . $campaign_id : '';
    $rows  = $db->query("SELECT * FROM contacts $where ORDER BY id LIMIT 1000")->fetchAll();
    jsonResponse($rows);
}

if ($method === 'POST') {
    // Массовое добавление номеров в существующую кампанию
    if (empty($body['campaign_id'])) jsonResponse(['error' => 'campaign_id required'], 422);
    if (empty($body['phones']))      jsonResponse(['error' => 'phones required'], 422);

    $cid    = (int)$body['campaign_id'];
    $phones = array_unique(array_filter(
        preg_split('/[\n,;]+/', $body['phones']),
        fn($p) => strlen(trim($p)) > 5
    ));

    $ins   = $db->prepare('INSERT IGNORE INTO contacts (campaign_id, phone) VALUES (?, ?)');
    $count = 0;
    foreach ($phones as $phone) {
        $clean = preg_replace('/\D/', '', trim($phone));
        if (strlen($clean) === 10) $clean = '7' . $clean;
        if (strlen($clean) === 11 && $clean[0] === '8') $clean[0] = '7';
        if (strlen($clean) >= 10) { $ins->execute([$cid, $clean]); $count++; }
    }
    jsonResponse(['added' => $count]);
}
