<?php
// ============================================================
// ivr.php — сохранение IVR плана для кампании
// ============================================================

$db   = getDB();
$body = getBody();

if ($method === 'POST') {
    $campaign_id = (int)($body['campaign_id'] ?? 0);
    $ivr_plan    = $body['ivr_plan'] ?? null;

    if (!$campaign_id) jsonResponse(['error' => 'campaign_id required'], 422);
    if (!$ivr_plan)    jsonResponse(['error' => 'ivr_plan required'], 422);

    $db->prepare('UPDATE campaigns SET ivr_plan = ? WHERE id = ?')
       ->execute([json_encode($ivr_plan, JSON_UNESCAPED_UNICODE), $campaign_id]);

    jsonResponse(['message' => 'IVR plan saved']);
}
