<?php
// ============================================================
// audio.php — список и загрузка аудио файлов
// ============================================================

$db = getDB();

if ($method === 'GET') {
    $rows = $db->query('SELECT * FROM audio_files ORDER BY label')->fetchAll();
    jsonResponse($rows);
}

if ($method === 'POST') {
    // Загрузка WAV файла через multipart/form-data
    if (empty($_FILES['file'])) jsonResponse(['error' => 'No file uploaded'], 422);

    $file     = $_FILES['file'];
    $origName = pathinfo($file['name'], PATHINFO_FILENAME);
    $ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!in_array($ext, ['wav', 'gsm', 'mp3', 'ulaw', 'alaw'])) {
        jsonResponse(['error' => 'Allowed: wav, gsm, mp3, ulaw, alaw'], 422);
    }

    // Очищаем имя файла
    $filename = preg_replace('/[^a-z0-9_\-]/', '_', strtolower($origName));
    $dest     = ASTERISK_SOUNDS . '/' . $filename . '.' . $ext;

    if (!is_dir(ASTERISK_SOUNDS)) {
        mkdir(ASTERISK_SOUNDS, 0755, true);
    }

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        jsonResponse(['error' => 'Failed to save file'], 500);
    }

    // Если mp3 — конвертируем в wav через sox (должен быть установлен)
    if ($ext === 'mp3') {
        $wavDest = ASTERISK_SOUNDS . '/' . $filename . '.wav';
        shell_exec("sox " . escapeshellarg($dest) . " -r 8000 -c 1 " . escapeshellarg($wavDest) . " 2>&1");
        unlink($dest);
    }

    // Записываем в БД
    $label = $_POST['label'] ?? $origName;
    $db->prepare('INSERT INTO audio_files (filename, label) VALUES (?, ?) ON DUPLICATE KEY UPDATE label = ?')
       ->execute([$filename, $label, $label]);

    // Меняем владельца файла на asterisk
    shell_exec('chown ' . ASTERISK_USER . ':' . ASTERISK_USER . ' ' . escapeshellarg($dest));

    jsonResponse(['filename' => $filename, 'message' => 'Audio uploaded']);
}
