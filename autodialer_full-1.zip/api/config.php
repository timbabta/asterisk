<?php
// ============================================================
// config.php — настройки подключения
// Отредактируйте под свои данные!
// ============================================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'autodialer');
define('DB_USER', 'autodialer_user');   // <-- ваш MySQL пользователь
define('DB_PASS', 'StrongPassword123'); // <-- ваш пароль

// Путь к папке с .call файлами Asterisk
define('ASTERISK_SPOOL', '/var/spool/asterisk/outgoing');

// Путь к аудио файлам (без расширения, Asterisk сам найдёт .wav/.gsm)
define('ASTERISK_SOUNDS', '/var/lib/asterisk/sounds/autodialer');

// Канал для исходящих (замените на ваш транк/провайдера)
define('ASTERISK_CHANNEL', 'SIP/provider');   // например SIP/mtt или DAHDI/g1

// Контекст в dialplan куда попадёт звонок после ответа
define('ASTERISK_CONTEXT', 'autodialer-ivr');

// От кого звоним (CallerID по умолчанию)
define('DEFAULT_CALLERID', '70000000000');

// Asterisk запущен от пользователя:
define('ASTERISK_USER', 'asterisk');

// ============================================================
// Не меняйте ниже этой строки
// ============================================================

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER, DB_PASS,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]
        );
    }
    return $pdo;
}

function jsonResponse(mixed $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function getBody(): array {
    return json_decode(file_get_contents('php://input'), true) ?? [];
}
