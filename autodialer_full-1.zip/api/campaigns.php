<?php
// ============================================================
// campaigns.php — CRUD для кампаний
// ============================================================

$db   = getDB();
$body = getBody();
$id   = (int)($_GET['id'] ?? 0);

// ── GET /api/?route=campaigns ───────────────────────────────
if ($method === 'GET') {
    if ($id) {
        // Одна кампания + статистика
        $stmt = $db->prepare('SELECT * FROM campaigns WHERE id = ?');
        $stmt->execute([$id]);
        $campaign = $stmt->fetch();
        if (!$campaign) jsonResponse(['error' => 'Not found'], 404);

        // Статистика контактов
        $stmt = $db->prepare('
            SELECT
                COUNT(*)                              AS total,
                SUM(status = "answered")              AS answered,
                SUM(status IN ("failed","max_retries")) AS failed,
                SUM(status = "calling")               AS calling,
                SUM(status = "pending")               AS pending
            FROM contacts WHERE campaign_id = ?
        ');
        $stmt->execute([$id]);
        $campaign['stats'] = $stmt->fetch();
        $campaign['ivr_plan'] = $campaign['ivr_plan'] ? json_decode($campaign['ivr_plan'], true) : null;
        jsonResponse($campaign);
    }

    // Список всех кампаний со статистикой
    $rows = $db->query('
        SELECT
            c.*,
            COUNT(ct.id)                                    AS total,
            SUM(ct.status = "answered")                     AS answered,
            SUM(ct.status IN ("failed","max_retries"))      AS failed,
            SUM(ct.status = "pending")                      AS pending,
            SUM(ct.status = "calling")                      AS calling
        FROM campaigns c
        LEFT JOIN contacts ct ON ct.campaign_id = c.id
        GROUP BY c.id
        ORDER BY c.created_at DESC
    ')->fetchAll();

    foreach ($rows as &$row) {
        $row['ivr_plan'] = $row['ivr_plan'] ? json_decode($row['ivr_plan'], true) : null;
    }
    jsonResponse($rows);
}

// ── POST /api/?route=campaigns — создать ─────────────────────
if ($method === 'POST') {
    $required = ['name', 'audio_file'];
    foreach ($required as $f) {
        if (empty($body[$f])) jsonResponse(['error' => "Field '$f' required"], 422);
    }

    $stmt = $db->prepare('
        INSERT INTO campaigns (name, audio_file, max_retries, retry_delay, time_from, time_to, caller_id, ivr_plan)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ');
    $stmt->execute([
        $body['name'],
        $body['audio_file'],
        (int)($body['max_retries']  ?? 3),
        (int)($body['retry_delay']  ?? 300),
        $body['time_from']  ?? '09:00:00',
        $body['time_to']    ?? '20:00:00',
        $body['caller_id']  ?? DEFAULT_CALLERID,
        isset($body['ivr_plan']) ? json_encode($body['ivr_plan']) : null,
    ]);
    $newId = $db->lastInsertId();

    // Добавляем телефоны если переданы
    if (!empty($body['phones'])) {
        $phones = array_unique(array_filter(
            preg_split('/[\n,;]+/', $body['phones']),
            fn($p) => preg_match('/^\+?[0-9]{10,15}$/', trim(preg_replace('/\D/', '', $p)))
        ));

        $ins = $db->prepare('INSERT INTO contacts (campaign_id, phone, name) VALUES (?, ?, ?)');
        foreach ($phones as $phone) {
            $clean = preg_replace('/\D/', '', trim($phone));
            if (strlen($clean) === 10) $clean = '7' . $clean; // 9XXXXXXXXX → 79XXXXXXXXX
            if (strlen($clean) === 11 && $clean[0] === '8') $clean[0] = '7'; // 8→7
            $ins->execute([$newId, $clean, $body['contact_names'][$clean] ?? null]);
        }
    }

    jsonResponse(['id' => $newId, 'message' => 'Campaign created'], 201);
}

// ── PUT /api/?route=campaigns&id=N — обновить ───────────────
if ($method === 'PUT') {
    if (!$id) jsonResponse(['error' => 'id required'], 422);

    $allowed = ['name','audio_file','status','max_retries','retry_delay','time_from','time_to','caller_id','ivr_plan'];
    $sets    = [];
    $vals    = [];

    foreach ($allowed as $field) {
        if (array_key_exists($field, $body)) {
            $sets[] = "$field = ?";
            $vals[] = $field === 'ivr_plan' ? json_encode($body[$field]) : $body[$field];
        }
    }

    if (!$sets) jsonResponse(['error' => 'Nothing to update'], 422);

    $vals[] = $id;
    $db->prepare('UPDATE campaigns SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($vals);
    jsonResponse(['message' => 'Updated']);
}

// ── DELETE /api/?route=campaigns&id=N ───────────────────────
if ($method === 'DELETE') {
    if (!$id) jsonResponse(['error' => 'id required'], 422);
    $db->prepare('DELETE FROM campaigns WHERE id = ?')->execute([$id]);
    jsonResponse(['message' => 'Deleted']);
}
